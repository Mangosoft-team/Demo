For installation and start the example see doc/install.txt
