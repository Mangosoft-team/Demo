package de.varengold.example.restcom.com;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.hibernate5.Hibernate5Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

/**
 * Responde message of a client GET/POST request.
 *
 * @param <E> ths returned POJO class
 */
@Getter
@Setter
@ToString
public class ActionResponse<E> {

  private enum ParserState {
    StartArray, ObjectOrEndArray, Null, End
  }

  /**
   * The state of the request.
   * <p>Can be:
   * <table><tr><td>{@link ActionState#Erroneous}</td><td>The request was not executed and the problem can not be resolved in the UI. The
   * reason can be an exception during database access or anything else.</td></tr></table>
   * <table><tr><td>{@link ActionState#Revoked}</td><td>The request was not executed but the problem can be resolved in the UI. The reason
   * can be a unfulfilled field constraint.</td></tr></table>
   * <table><tr><td>{@link ActionState#Success}</td><td>The request was successful executed.</td></tr></table>
   * </p>
   */
  @NotNull
  private ActionState actionState;

  /**
   * List of field formats.
   * <p>Can be empty but never <code>null</code>.</p>
   */
  @NotNull
  private Map<String, FieldFormat> fieldFormatMap;
  /**
   * List of messages that should be displayed at field or view level.
   * <p>Can be empty but never <code>null</code>.</p>
   */
  @NotNull
  private List<FieldMessage> fieldMessages;
  /**
   * List with POJOs that content should be displayed.
   * <p>Can be empty but never <code>null</code>.</p>
   * <p>A request for a simple non editable view have normally only one POJO. At requests for comboboxes all possible entries will be
   * returned.</p>
   */
  @JsonIgnore
  private List<E> data;

  /**
   * Name of the generic data class.
   */
  private String dataClassName;
  /**
   * JSON formatted String of {@link #data}.
   *
   * <p>We use this String to transfer the {@link #data} between server and client and vice versa. Otherwise we lost type information, need
   * extra code for every call or have ugly type conversions.</p>
   */
  private String dataString;

  public List<E> getData() {
    if (data == null) {
      try {
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(dataString);

        ObjectMapper objectMapper = Jackson2ObjectMapperBuilder.json()
            .serializationInclusion(JsonInclude.Include.NON_NULL) // Don’t include null values
            .featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS) //ISODate
            .modules(new JavaTimeModule())
            .build();

        Class<?> dataClass = Class.forName(dataClassName);

        data = new ArrayList<>();

        ParserState parserState = ParserState.StartArray;

        while (!parser.isClosed()) {
          JsonToken jsonToken = parser.nextToken();

          if (JsonToken.START_ARRAY.equals(jsonToken)) {
            if (parserState == ParserState.StartArray) {
              parserState = ParserState.ObjectOrEndArray;
            } else {
              throw new RuntimeException("Unexpected token '" + jsonToken.toString() + "'; expected '" + JsonToken.START_ARRAY + "'");
            }
          } else if (JsonToken.START_OBJECT.equals(jsonToken)) //noinspection SingleStatementInBlock
          {
            if (parserState != ParserState.ObjectOrEndArray) {
              throw new RuntimeException(
                  "Unexpected token '" + jsonToken.toString() + "'; expected '" + JsonToken.START_OBJECT + "' or '" + JsonToken.END_ARRAY
                      + "'");
            }

            @SuppressWarnings("unchecked")
            E dataObject = (E) objectMapper.readValue(parser, dataClass);
            data.add(dataObject);
          } else if (JsonToken.END_ARRAY.equals(jsonToken)) {
            if (parserState == ParserState.ObjectOrEndArray) {
              parserState = ParserState.Null;
            } else {
              throw new RuntimeException("Unexpected token '" + jsonToken.toString() + "'; expected '" + JsonToken.START_ARRAY + "'");
            }
          } else if (jsonToken == null) {
            if (parserState == ParserState.Null) {
              parserState = ParserState.End;
            } else {
              throw new RuntimeException("Unexpected token 'null'; expected 'null'");
            }

          } else {
            throw new RuntimeException("Unexpected token '" + jsonToken.toString() + "' in State '" + parserState + "'");
          }
        }

      } catch (IOException | ClassNotFoundException e) {
        throw new RuntimeException(e);
      }
    }

    return data;
  }

  public void setData(E data) {
    ArrayList<E> dataList = new ArrayList<>(1);
    dataList.add(data);

    setData(dataList);
  }

  public void setData(List<E> data) {
    if (data.size() > 0) {
      dataClassName = data.get(0).getClass().getName();
    } else {
      dataClassName = Object.class.getName();
    }

    final StringWriter sw = new StringWriter();
    final ObjectMapper mapper = Jackson2ObjectMapperBuilder.json()
        .serializationInclusion(JsonInclude.Include.NON_NULL) // Don’t include null values
        .featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS) //ISODate
        .modules(new JavaTimeModule())
        .build();

    mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

    mapper.registerModule(new Hibernate5Module());

    try {
      mapper.writeValue(sw, data);
      dataString = sw.toString();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }


}
