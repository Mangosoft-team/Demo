package de.varengold.example.restcom.com;

/**
 * Description of the formatter/parser that should be used for {@link FieldFormat#formatterValue}.
 *
 * <table>
 * <tr><th>Value</th><th>Type</th><th>Description</th></tr>
 * <tr><td>RegEx</td><td>Parser</td><td>Input values must match the expression.</td></tr>
 * <tr><td>DecimalFormat</td><td>Formatter</td><td>Display format</td></tr>
 * <tr><td>DecimalFormat</td><td>Parser</td><td>Input values must math the expression.</td></tr>
 * <tr><td>SimpleDateFormat</td><td>Formatter</td><td>Display format</td></tr>
 * <tr><td>SimpleDateFormat</td><td>Parser</td><td>Input values must math the expression.</td></tr>
 * <tr><td>Formatter</td><td>Formatter</td><td>Display format</td></tr>
 * </table>
 */
public enum FormatterType {
  /**
   * {@link FieldFormat#formatterValue} (if any) should be ignored, the value should be displayed and transferred "as is".
   */
  None,

  /**
   * {@link FieldFormat#formatterValue} has a RegEx expression that must be match.
   */
  RegEx,

  /**
   * {@link FieldFormat#formatterValue} has a {@link java.text.DecimalFormat} pattern that must be match and used for formatting.
   */
  DecimalFormat,

  /**
   * {@link FieldFormat#formatterValue} has a {@link java.text.SimpleDateFormat} pattern that must be match and used for formatting.
   */
  SimpleDateFormat,

  /**
   * {@link FieldFormat#formatterValue} has a {@link java.util.Formatter} pattern that must be used for formatting.
   */
  Formatter
}
