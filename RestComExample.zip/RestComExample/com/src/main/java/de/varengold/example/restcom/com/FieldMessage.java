package de.varengold.example.restcom.com;

import javax.validation.constraints.NotNull;

/**
 * A message that should be displayed at field or view level.
 * <p>Messages should be displayed by
 * <ul>
 *   <li>highlight the field and show the message in a tooltip</li>
 *   <li>display the message in a message area with a link to the field(s).</li>
 *   <li>display the message in a messagebox.</li>
 * </ul>
 *
 * ing </p>
 */
public class FieldMessage {

  /**
   * The name of the field that should receive this message.
   * <p>If no field name is specified (<code>null</code> or empty), the message should be displayed as a messagebox.</p>
   */
  private String fieldName;
  /**
   * The message that should be displayed.
   */
  @NotNull
  private String message;

}
