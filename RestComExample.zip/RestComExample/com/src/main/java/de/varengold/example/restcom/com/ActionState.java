package de.varengold.example.restcom.com;

/**
 * Server side execution state of a request.
 */
public enum ActionState {
  /**
   * The request was not executed and the problem can not be resolved in the UI. The reason can be an exception during database access or
   * anything else.
   */
  Erroneous,

  /**
   * The request was not executed but the problem can be resolved in the UI. The reason can be a unfulfilled field constraint.
   */
  Revoked,

  /**
   * The request was successful executed.
   */
  Success
}
