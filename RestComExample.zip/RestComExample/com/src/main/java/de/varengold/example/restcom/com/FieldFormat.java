package de.varengold.example.restcom.com;

import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Format an constraints for one field.
 *
 * <p><b>Interpretation of {@link #minValue} and {@link #minValue}:</b></p>
 * <table>
 * <tr><th>Field type</th><th>Interpretation</th></tr>
 * <tr><td>{@link String}</td><td>The {@link String#length()} of the string.</td></tr>
 * <tr><td>{@link Number Numbers}</td><td>The minimum and maximum number value.</td></tr>
 * <tr><td>Dates, times and datetimes}</td><td>The minimum and maximum value.</td></tr>
 * <tr><td>Enum </td><td>{@link #minValue} and {@link #minValue} are not specified.</td></tr>
 * </table>
 */
@Getter
@Setter
@ToString
public class FieldFormat {


  /**
   * The field is visible (<code>true</code>) or should be hide (<code>false</code>.
   * <p>In most cases hide fields are internal ids.</p>
   */
  @NotNull
  private boolean visible;
  /**
   * The field is enabled <code>true</code> or disabled <code>false</code>.
   * <p>Disabled UI components are visible but have no internal action like select another value of a combobox or another line in table but
   * the user can scroll them to see the other entries.</p>
   */
  @NotNull
  private boolean enabled;
  /**
   * The field is editable (<code>true</code>) or not (<code>false</code>).
   * <p>Mostly used for textfields but sometimes for special cases for a combobox.</p>
   * <p><b>To edit a value in a textfield <code>editable</code>, {@link #enabled} and {@link #visible} must be true.</b></p>
   */
  @NotNull
  private boolean editable;
  /**
   * The field can be <code>null</code>. That means a textfield with an {@link String#isEmpty()} == <code>true</code> sets the value in the
   * POJO to <code>null</code>.
   */
  @NotNull
  private boolean nullable;
  /**
   * Describe the formatter/parser that should be used.
   * <p>A <code>null</code> value must be interpreted as {@link FormatterType#None}.</p>
   */
  private FormatterType formatter;
  /**
   * The pattern for the {@link #formatter}.
   * <p><b>For {@link FormatterType#None} the value should be <code>null</code>.</b></p>
   */
  private String formatterValue;
  /**
   * The minimum number of a field or field length.
   * <p>If only a number is specified, the minimum is include the given value. If the number has a leading greater than character ('>') the
   * minimum is exclude the give value.<br/>Examples:<ul><li>For a <code>minValue = ">3"</code> the minimum allowed integer value is
   * 4.</li><li>For a <code>minValue = "3"</code> the minimum allowed integer value is 3.</li><li>For a <code>minValue = ">2017-12-31"</code> the
   * minimum allowed date value is the '2018-01-01'.</li></ul>
   * <p><b>A <code>null</code> or empty value specifies there is no minimum restriction.</b></p>
   */
  private String minValue;
  /**
   * The maximum number of a field or field length.
   * <p>If only a number is specified, the maximum is include the given value. If the number has a leading lower than character ('<') the
   * maximum is exclude the give value.<br/>Examples:<ul><li>For a <code>maxValue = "<10"</code> the maximum allowed integer value is
   * 9.</li><li>For a <code>maxValue</code> = "10" the maximum allowed integer value is 10.</li><li>For a <code>maxValue} = "<2018-08-01"</code> the
   * maximum allowed date value is the '2018-07-31'.</li></ul>
   * <p><b>A <code>null</code> or empty value specifies there is no maximum restriction.</b></p>
   */
  private String maxValue;
}
