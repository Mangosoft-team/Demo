package de.varengold.example.restcom.server.model;


import java.time.LocalDate;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@ToString
@FieldNameConstants
public class Person {
  private long id;

  private String firstName;
  private String lastName;
  private Country countryOfBirth;
  private LocalDate dateOfBirth;

  private List<Email> emails;
  private List<Address> addresses;
}
