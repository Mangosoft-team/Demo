package de.varengold.example.restcom.server.model;


import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
@Setter
@ToString
public class Address {

  private long id;

  private Country country;
  private String zipcode;
  private String city;
  private String street;
  private String from;
  private String till;
}
