package de.varengold.example.restcom.server.controller;

import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.com.ActionState;
import de.varengold.example.restcom.com.FieldFormat;
import de.varengold.example.restcom.com.FormatterType;
import de.varengold.example.restcom.server.model.Address;
import de.varengold.example.restcom.server.model.Country;
import de.varengold.example.restcom.server.model.Email;
import de.varengold.example.restcom.server.model.Person;
import de.varengold.example.restcom.server.model.SelectPerson;
import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/person")
public class PersonController {

  //
  // Initial data
  //

  Country[] countries = new Country[]{
      new Country(1, "Finland"),
      new Country(2, "Germany"),
      new Country(3, "Spain"),
      new Country(4, "Sweden"),
      new Country(5, "United Kingdom")};

  private Person[] persons = new Person[]{
      new Person(1, "Michael", "Müller", countries[1], LocalDate.of(1972, 4, 28),
          Arrays.asList(new Email[]{new Email(0, "mm@gmx.de"), new Email(1, "m.mueller@varengold.de")}),
          Arrays.asList(new Address[]{new Address(1, countries[2], "20354", "Hamburg", "Neuer Jungfernstieg", null, null)})),
      new Person(2, "Anton", "Schulze", countries[0], LocalDate.of(1965, 1, 04),
          Arrays.asList(new Email[]{new Email(2, "as@gmail.de"), new Email(3, "a.schulze@varengold.de")}),
          Arrays.asList(new Address[]{new Address(1, countries[1], "20354", "Hamburg", "Grosse Theaterstrasse", null, null),
              new Address(1, countries[2], "25001", "Lleida", "Carrer del Sifó", null, null)})),
      new Person(3, "Berta", "Schmidt", countries[3], LocalDate.of(1950, 4, 5),
          Arrays.asList(new Email[]{new Email(4, "bs@hotmail.de"), new Email(5, "b.schmidt@varengold.de")}),
          Arrays.asList(new Address[]{new Address(1, countries[2], "22767", "Hamburg", "Grosse Elbstrasse", null, null)})),
  };

  //
  // Selection view
  //

  /**
   * Initial initialisation of the select view
   * <p>The data fields are set to "<i>Beginning of previous month</i>" and "<i>today</i>".</p>
   *
   * @return Initial view data.
   */
  @RequestMapping("/initSelect")
  public ActionResponse<SelectPerson> initSelect() {
    System.out.println("PersonController.initSelect");

    LocalDate now = LocalDate.now();
    LocalDate from = now.minusDays(now.getDayOfMonth() - 1).minusMonths(1);

    SelectPerson selectPerson = new SelectPerson(from, now);

    ActionResponse<SelectPerson> actionResponse = new ActionResponse<>();
    actionResponse.setActionState(ActionState.Success);

    ArrayList<SelectPerson> dataList = new ArrayList<>();
    dataList.add(selectPerson);

    actionResponse.setData(dataList);

    return actionResponse;
  }

  /**
   * Load the perons between given date span.
   *
   * @param actionRequest the selection criteria from the view.
   * @return The list with the persons.
   */
  @RequestMapping("/loadSelection")
  public ActionResponse<Person> loadSelect(@RequestBody ActionResponse<SelectPerson> actionRequest) {
    SelectPerson selectPerson = actionRequest.getData().get(0);

    System.out.println("PersonController.loadSelect selectPerson#From: " + selectPerson.getFrom());
    System.out.println("PersonController.loadSelect selectPerson#Till: " + selectPerson.getTill());

    ActionResponse<Person> actionResponse = new ActionResponse<>();
    actionResponse.setActionState(ActionState.Success);

    ArrayList<Person> dataList = new ArrayList<>(Arrays.asList(persons));

    actionResponse.setData(dataList);

    return actionResponse;
  }

  //
  // Person view
  //

  /**
   * Initial initialisation of the person view.
   * <p>The user "a" get no access to the email part.</p>
   *
   * @return Initial view data.
   */
  @RequestMapping("/initPerson")
  public ActionResponse<Person> initPerson(Principal p) {
    ActionResponse<Person> actionResponse = new ActionResponse<>();

    Map<String, FieldFormat> fieldFormats = new HashMap<>();

    switch (p.getName()) {
      case "a":
        FieldFormat fieldFormat = new FieldFormat();
        fieldFormat.setEnabled(false);
        fieldFormats.put("tabEmail", fieldFormat);
        break;
      default:
        break;
    }

    actionResponse.setFieldFormatMap(fieldFormats);

    return actionResponse;
  }

  /**
   * Country list/combo box for the person view.
   *
   * @return Initial data of the list/combo box
   */
  @RequestMapping("/initPersonCountry")
  public ActionResponse<Country> initPersonCountry() {
    ActionResponse<Country> actionResponse = new ActionResponse<>();
    actionResponse.setActionState(ActionState.Success);

    actionResponse.setData(Arrays.asList(countries));

    return actionResponse;
  }


  @RequestMapping("/personDetail")
  public ActionResponse<Person> personDetail(Principal p, @RequestBody ActionResponse<Person> actionRequest) {
    ActionResponse<Person> actionResponse = new ActionResponse<>();
    actionResponse.setActionState(ActionState.Success);

    List<Person> requestData = actionRequest.getData();
    Person person = requestData.get(0);

    int idx = 0;
    while ((idx < persons.length) && (persons[idx].getId() != person.getId())) {
      idx++;
    }

    ArrayList<Person> dataList = new ArrayList<>(1);
    dataList.add(persons[idx]);

    actionResponse.setData(dataList);

    //
    // Field restrictions and formats
    //

    FieldFormat fieldFormat;
    Map<String, FieldFormat> fieldFormats = new HashMap<>();

    switch (p.getName()) {
      case "a":
        fieldFormat = new FieldFormat();

        fieldFormat.setFormatter(FormatterType.SimpleDateFormat);
        fieldFormat.setFormatterValue("dd.MM.yyyy");
        fieldFormats.put(Person.FIELD_DATE_OF_BIRTH, fieldFormat);
        break;
      case "b":
        fieldFormat = new FieldFormat();

        fieldFormat.setFormatter(FormatterType.SimpleDateFormat);
        fieldFormat.setFormatterValue("MM/dd/yyyy");
        fieldFormats.put(Person.FIELD_DATE_OF_BIRTH, fieldFormat);
        break;
      default:
        break;
    }
    actionResponse.setFieldFormatMap(fieldFormats);

    return actionResponse;
  }

  @RequestMapping("/initPersonEmail")
  public ActionResponse<Email> initPersonEmail(@RequestBody ActionResponse<Person> actionRequest) {
    ActionResponse<Email> actionResponse = new ActionResponse<>();
    actionResponse.setActionState(ActionState.Success);

    List<Person> requestData = actionRequest.getData();
    Person person = requestData.get(0);

    int idx = 0;
    while ((idx < persons.length) && (persons[idx].getId() != person.getId())) {
      idx++;
    }

    actionResponse.setData(persons[idx].getEmails());

    return actionResponse;
  }


  @RequestMapping("/initPersonAddress")
  public ActionResponse<Address> initPersonAddress(Principal p, @RequestBody ActionResponse<Person> actionRequest) {
    ActionResponse<Address> actionResponse = new ActionResponse<>();

    List<Person> requestData = actionRequest.getData();
    Person person = requestData.get(0);

    int idx = 0;
    while ((idx < persons.length) && (persons[idx].getId() != person.getId())) {
      idx++;
    }

    actionResponse.setData(persons[idx].getAddresses());

    Map<String, FieldFormat> fieldFormats = new HashMap<>();

    switch (p.getName()) {
      case "b":
        FieldFormat fieldFormat = new FieldFormat();
        fieldFormat.setEnabled(false);
        fieldFormats.put("btnAdd", fieldFormat);

        fieldFormat = new FieldFormat();
        fieldFormat.setEnabled(false);
        fieldFormats.put("btnDelete", fieldFormat);
        break;
      default:
        break;
    }

    actionResponse.setFieldFormatMap(fieldFormats);
    actionResponse.setActionState(ActionState.Success);

    return actionResponse;
  }

}
