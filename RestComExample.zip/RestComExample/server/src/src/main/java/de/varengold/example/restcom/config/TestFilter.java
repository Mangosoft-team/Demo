package de.varengold.example.restcom.config;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.keycloak.representations.AccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TestFilter  implements Filter {

//  @Autowired
// private AccessToken accessToken;

  @Override
  public void init(FilterConfig filterConfig) throws ServletException {
    System.out.println("TestFilter.init");
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
      HttpServletRequest req = (HttpServletRequest) request;

    System.out.println("TestFilter.doFilter request "+((HttpServletRequest) request).getRequestURI());
    System.out.println("TestFilter.doFilter request "+((HttpServletRequest) request).getRemoteUser());
    System.out.println("TestFilter.doFilter request "+((HttpServletRequest) request).getUserPrincipal());

    if (((HttpServletRequest) request).getRequestURI().equals("/varengold/srs/update")) {
      ((HttpServletResponse) response).sendError(HttpServletResponse.SC_UNAUTHORIZED, "No no never.");
    } else {
      chain.doFilter(request, response);
    }
  }

  @Override
  public void destroy() {
    System.out.println("TestFilter.destroy");
  }
}