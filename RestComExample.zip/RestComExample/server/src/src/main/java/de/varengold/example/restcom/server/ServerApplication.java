package de.varengold.example.restcom.server;

import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.server.model.Person;
import java.util.ArrayList;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan(basePackages = {"de.varengold.example.restcom.config", "de.varengold.example.restcom.server.controller"})

public class ServerApplication {


  public static void main(String[] args) {

    List<Person> data = new ArrayList<>();

    ActionResponse<Person> actionResponse = new ActionResponse<>();
    actionResponse.setData(data);

    SpringApplication.run(ServerApplication.class, args);
  }
}
