package de.varengold.example.restcom.client.ui.operations;

import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Button;
import com.vaadin.ui.Grid;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.TabSheet;
import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.com.FieldFormat;
import de.varengold.example.restcom.server.model.Email;
import de.varengold.example.restcom.server.model.Person;
import de.varengold.example.restcom.client.service.MyBackend;
import de.varengold.example.restcom.client.ui.views.PersonView;
import de.varengold.example.restcom.client.ui.views.TabCard;
import java.util.List;
import java.util.Map;

public class EmailTab extends TabCard<Email> {

private   Grid<Email> emailGrid;
  private MyBackend backend;

  public EmailTab(MyBackend backend , TabSheet tabSheet) {
    super(tabSheet);
    this.backend = backend;
  }

  @Override
  protected void doInit() {
    //
    // Init call of the view (neutral or specified)
    //

    long id = (long) VaadinSession.getCurrent().getAttribute(PersonView.VIEW_NAME + ".Id");

    Person requestedPerson = new Person();
    requestedPerson.setId(id);

    ActionResponse<Email> actionResponseEmail = backend.initPersonEmail(requestedPerson);

    //
    // Declare UI components
    //

    Button btnUpdate = new Button("Update");
    Button btnAdd = new Button("Add");
    Button btnDelete = new Button("Delete");

    emailGrid = new Grid<>();

    emailGrid.addColumn(Email::getAddress).setCaption("E-Mail address");

    //
    // Compose UI components
    //

    addComponent(emailGrid);

    HorizontalLayout hl = new HorizontalLayout();
    hl.addComponents(btnUpdate, btnAdd, btnDelete);

    addComponent(hl);

    //
    // Carrying of init call
    //

    setValues(actionResponseEmail.getData(),actionResponseEmail.getFieldFormatMap());
  }


  @Override
  protected void setValues(List<Email> values, Map<String, FieldFormat> fieldFormatMap) {
    emailGrid.setItems(values);
  }
}
