package de.varengold.example.restcom.client.service;

import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.server.model.Address;
import de.varengold.example.restcom.server.model.Country;
import de.varengold.example.restcom.server.model.Email;
import de.varengold.example.restcom.server.model.Person;
import de.varengold.example.restcom.server.model.SelectPerson;
import java.util.ArrayList;
import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MyBackendBean implements MyBackend {


  @SuppressWarnings("unused")
  @Autowired
  private KeycloakRestTemplate restTemplate;

  private String rootUrl = "http://localhost:10001/varengold/srs/person";

  //
  // Selection view
  //

  @Override
  public ActionResponse<SelectPerson> initSelect() {
    ActionResponse<SelectPerson> selectPerson = restTemplate.getForObject(rootUrl + "/initSelect", ActionResponse.class);

    return selectPerson;
  }

  @Override
  public ActionResponse<Person> loadSelection(SelectPerson selectPersonToServer) {
    ActionResponse<SelectPerson> actionRequest = new ActionResponse<>();

    ArrayList<SelectPerson> inList = new ArrayList<>();
    inList.add(selectPersonToServer);
    actionRequest.setData(inList);

    ActionResponse<Person> selectPersons = restTemplate.postForObject(rootUrl + "/loadSelection", actionRequest, ActionResponse.class);

    return selectPersons;
  }

  //
  // Person view
  //

  @Override
  public ActionResponse<Person> initPerson() {
    ActionResponse<Person> person = restTemplate.getForObject(rootUrl + "/initPerson", ActionResponse.class);

    return person;
  }

  public ActionResponse<Person> personDetail(Person person) {
    ActionResponse<Person> actionRequest = new ActionResponse<>();

    ArrayList<Person> inList = new ArrayList<>();
    inList.add(person);
    actionRequest.setData(inList);

    ActionResponse<Person> personDetail = restTemplate.postForObject(rootUrl + "/personDetail", actionRequest, ActionResponse.class);

    return personDetail;
  }


  @Override
  public ActionResponse<Email> initPersonEmail(Person person) {
    ActionResponse<Person> actionRequest = new ActionResponse<>();

    ArrayList<Person> inList = new ArrayList<>();
    inList.add(person);
    actionRequest.setData(inList);

    ActionResponse<Email> emailDetail = restTemplate.postForObject(rootUrl + "/initPersonEmail", actionRequest, ActionResponse.class);

    return emailDetail;
  }

  @Override
  public ActionResponse<Address> initPersonAddress(Person person) {
    ActionResponse<Person> actionRequest = new ActionResponse<>();

    ArrayList<Person> inList = new ArrayList<>();
    inList.add(person);
    actionRequest.setData(inList);

    ActionResponse<Address> addressInitilisation = restTemplate.postForObject(rootUrl + "/initPersonAddress",actionRequest, ActionResponse.class);

    return addressInitilisation;
  }


  @Override
  public ActionResponse<Country> initPersonCountry() {
    ActionResponse<Country> countryInitilisation = restTemplate.getForObject(rootUrl + "/initPersonCountry", ActionResponse.class);

    return countryInitilisation;
  }


}
