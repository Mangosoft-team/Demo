package de.varengold.example.restcom.client;

import org.keycloak.adapters.springsecurity.client.KeycloakClientRequestFactory;
import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;

@SpringBootApplication
public class ClientApplication {
  @Autowired
  public KeycloakClientRequestFactory keycloakClientRequestFactory;


  public static void main(String[] args) {
    SpringApplication.run(ClientApplication.class, args);
  }


  @Bean
  public KeycloakClientRequestFactory keycloakClientRequestFactory(){
    return new KeycloakClientRequestFactory();
  }

  @Bean
  @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
  public KeycloakRestTemplate keycloakRestTemplate() {
    return new KeycloakRestTemplate(keycloakClientRequestFactory);
  }
}
