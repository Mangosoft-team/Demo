package de.varengold.example.restcom.client.ui.views;

import static de.varengold.example.restcom.client.ui.views.PersonView.VIEW_NAME;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.navigator.SpringNavigator;
import com.vaadin.ui.Layout;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.VerticalLayout;
import de.varengold.example.restcom.client.ui.operations.EmailTab;
import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.server.model.Person;
import de.varengold.example.restcom.client.service.MyBackend;
import org.springframework.beans.factory.annotation.Autowired;

@SpringView(name = VIEW_NAME)
@SuppressWarnings("serial")
public class PersonView extends VerticalLayout implements View {

  public final static String VIEW_NAME = "PersonView";

  @Autowired
  private SpringNavigator navigator;

  @Autowired
  public PersonView(MyBackend backend) {
    setSpacing(true);
    setMargin(true);

    //
    // Init call of the view (neutral or specified)
    //

    ActionResponse<Person> actionResponse = backend.initPerson();

    //
    // Declare UI components
    //

    TabSheet tabsheet = new TabSheet();

    tabsheet.addSelectedTabChangeListener(event -> {
      // Find the TabSheet
      TabSheet selectedTabSheet = event.getTabSheet();

      // Find the tab (here we know it's a layout)
      Layout tab = (Layout) selectedTabSheet.getSelectedTab();

      if (tab instanceof TabCard) {
        TabCard tabCard = (TabCard) tab;

        tabCard.init();
      }
    });

    // Create the tabs
    PersonTab personTab = new PersonTab(backend, tabsheet);
    EmailTab emailTab = new EmailTab(backend, tabsheet);
    AddressTab addressTab = new AddressTab(backend, tabsheet);

    //
    // Compose UI components
    //

    tabsheet.addTab(personTab, "Base data");
    tabsheet.addTab(emailTab, "Email");
    tabsheet.addTab(addressTab, "Address");

    addComponent(tabsheet);

    //
    // Carrying of init call
    //

    personTab.setEnabled(true);
    emailTab.setEnabled(true);
    addressTab.setEnabled(true);

    actionResponse.getFieldFormatMap().forEach((key,ff) -> {
      switch (key) {
        case "tabEmail":
          emailTab.setFieldFormat(ff);
          break;
      }
    });
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent event) {
  }
}
