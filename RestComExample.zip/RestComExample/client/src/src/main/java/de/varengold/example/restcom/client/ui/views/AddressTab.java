package de.varengold.example.restcom.client.ui.views;

import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Button;
import com.vaadin.ui.Grid;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.TabSheet;
import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.com.FieldFormat;
import de.varengold.example.restcom.server.model.Address;
import de.varengold.example.restcom.server.model.Person;
import de.varengold.example.restcom.client.service.MyBackend;
import java.util.List;
import java.util.Map;

public class AddressTab extends TabCard<Address> {

  private final MyBackend backend;
  private Grid<Address> addressGrid;

  public AddressTab(MyBackend backend, TabSheet tabSheet) {
    super(tabSheet);
    this.backend = backend;
  }

  @Override
  protected void doInit() {
    //
    // Init call of the view (neutral or specified)
    //

    long id = (long) VaadinSession.getCurrent().getAttribute(PersonView.VIEW_NAME + ".Id");

    Person requestedPerson = new Person();
    requestedPerson.setId(id);

    ActionResponse<Address> actionResponse = backend.initPersonAddress(requestedPerson);

    //
    // Declare UI components
    //

    Button btnUpdate = new Button("Update");
    Button btnAdd = new Button("Add");
    Button btnDelete = new Button("Delete");

    addressGrid = new Grid<>();
    addressGrid.addColumn(Address::getCountry, country -> {
      return country.getName();
    }).setCaption("Country");
    addressGrid.addColumn(Address::getZipcode).setCaption("Zipcode");
    addressGrid.addColumn(Address::getCity).setCaption("City");
    addressGrid.addColumn(Address::getStreet).setCaption("Caption");
    addressGrid.addColumn(Address::getFrom).setCaption("From");
    addressGrid.addColumn(Address::getTill).setCaption("Till");

    //
    // Compose UI components
    //

    addComponent(addressGrid);

    HorizontalLayout hl = new HorizontalLayout();
    hl.addComponents(btnUpdate, btnAdd, btnDelete);

    addComponent(hl);

    //
    // Carrying of init call
    //

    btnAdd.setEnabled(true);
    btnDelete.setEnabled(true);

    actionResponse.getFieldFormatMap().forEach((key, ff) -> {
      switch (key) {
        case "btnAdd":
          setFieldFormat(btnAdd, ff);
          break;
        case "btnDelete":
          setFieldFormat(btnDelete, ff);
          break;
      }
    });

    setValues(actionResponse.getData(), actionResponse.getFieldFormatMap());

  }

  @Override
  protected void setValues(List<Address> values, Map<String, FieldFormat> fieldFormatMap) {
    addressGrid.setItems(values);
  }
}
