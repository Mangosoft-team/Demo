package de.varengold.example.restcom.client.service;

import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.server.model.Address;
import de.varengold.example.restcom.server.model.Country;
import de.varengold.example.restcom.server.model.Email;
import de.varengold.example.restcom.server.model.Person;
import de.varengold.example.restcom.server.model.SelectPerson;

public interface MyBackend {
  ActionResponse<SelectPerson> initSelect();

  ActionResponse<Person> loadSelection( SelectPerson selectPersonToServer);

  ActionResponse<Person> personDetail(Person person);

  ActionResponse<Country> initPersonCountry();

  ActionResponse<Person> initPerson();

  ActionResponse<Email> initPersonEmail(Person requestedPerson);

  ActionResponse<Address> initPersonAddress(Person requestedPerson);
}
