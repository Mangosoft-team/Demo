package de.varengold.example.restcom.client.ui.views;

import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.VerticalLayout;
import de.varengold.example.restcom.com.FieldFormat;
import de.varengold.example.restcom.server.model.Person;
import java.util.List;
import java.util.Map;

public abstract class TabCard<V> extends VerticalLayout {

  private boolean initialised;
  private TabSheet tabSheet;

  public TabCard(TabSheet tabSheet) {
    this.tabSheet = tabSheet;

    initialised = false;
  }

  public void init() {
    if (!initialised) {
      doInit();

      initialised = true;
    }
  }

  protected abstract void doInit();

  public void setFieldFormat(FieldFormat fieldFormat) {
    tabSheet.getTab(this).setEnabled(fieldFormat.isEnabled());
  }

  protected void setFieldFormat(AbstractComponent component, FieldFormat fieldFormat) {
    component.setEnabled(fieldFormat.isEnabled());
  }

  protected void setValue(Person person,
      Map<String, FieldFormat> fieldFormatMap) {
    throw new UnsupportedOperationException();
  }

  protected void setValues(List<V> values, Map<String, FieldFormat> fieldFormatMap) {
    throw new UnsupportedOperationException();
  }
}
