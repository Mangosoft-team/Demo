package de.varengold.example.restcom.client.ui.views;

import com.vaadin.server.VaadinSession;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.TextField;
import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.com.FieldFormat;
import de.varengold.example.restcom.com.FormatterType;
import de.varengold.example.restcom.server.model.Country;
import de.varengold.example.restcom.server.model.Person;
import de.varengold.example.restcom.client.service.MyBackend;
import java.util.List;
import java.util.Map;

public class PersonTab extends TabCard<Person> {


  private MyBackend backend;

  private TextField tfLastName;
  private TextField tfFirstName;
  private ComboBox<Country> cboCountryOfBirth;
  private DateField dfDateOfBirth;


  public PersonTab(MyBackend backend , TabSheet tabSheet) {
    super(tabSheet);
    this.backend = backend;
  }

  @Override
  protected void doInit() {
    FormLayout form = new FormLayout();

    //
    // Init call of the view (neutral or specified)
    //

    // ComboBoxes
    ActionResponse<Country> actionResponsePersonCountry = backend.initPersonCountry();

    // Dialog data and field restrictions
    long id = (long) VaadinSession.getCurrent().getAttribute(PersonView.VIEW_NAME + ".Id");

    Person requestedPerson = new Person();
    requestedPerson.setId(id);

    ActionResponse<Person> actionResponsePerson = backend.personDetail(requestedPerson);

    //
    // Declare UI components
    //

    tfLastName = new TextField("Last name");
    tfFirstName = new TextField("First name");

    cboCountryOfBirth = new ComboBox<>("Country of birth");
    cboCountryOfBirth.setItemCaptionGenerator(Country::getName);

    dfDateOfBirth = new DateField("Date of birth");

    //
    // Carrying of init call
    //

    List<Country> countries = actionResponsePersonCountry.getData();
    cboCountryOfBirth.setItems(countries);

    Person person = actionResponsePerson.getData().get(0);
    setValue(person, actionResponsePerson.getFieldFormatMap());

    //
    // Compose UI components
    //

    form.addComponent(tfLastName);
    form.addComponent(tfFirstName);
    form.addComponent(cboCountryOfBirth);
    form.addComponent(dfDateOfBirth);

    addComponent(form);
  }


  @Override
  protected void setValue(Person person, Map<String, FieldFormat> fieldFormatMap) {
    tfLastName.setValue(person.getLastName());
    tfFirstName.setValue(person.getFirstName());
    cboCountryOfBirth.setSelectedItem(person.getCountryOfBirth());

    FieldFormat fieldFormat = fieldFormatMap.get(Person.FIELD_DATE_OF_BIRTH);
    if (fieldFormat!=null){
      dfDateOfBirth.setValue(person.getDateOfBirth());
      if (fieldFormat.getFormatter()== FormatterType.SimpleDateFormat){
        dfDateOfBirth.setDateFormat(fieldFormat.getFormatterValue());
      }
    }
  }

  @Override
  protected void setValues(List<Person> values, Map<String, FieldFormat> fieldFormatMap) {
    throw new UnsupportedOperationException();
  }
}
