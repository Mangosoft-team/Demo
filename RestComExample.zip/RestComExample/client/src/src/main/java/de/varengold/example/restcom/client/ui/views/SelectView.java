package de.varengold.example.restcom.client.ui.views;

import com.vaadin.icons.VaadinIcons;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.VaadinSession;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.spring.navigator.SpringNavigator;
import com.vaadin.ui.Button;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import de.varengold.example.restcom.com.ActionResponse;
import de.varengold.example.restcom.server.model.Person;
import de.varengold.example.restcom.server.model.SelectPerson;
import de.varengold.example.restcom.client.service.MyBackend;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.vaadin.spring.sidebar.annotation.SideBarItem;
import org.vaadin.spring.sidebar.annotation.VaadinFontIcon;

@SuppressWarnings("serial")
@SpringView(name = SelectView.VIEW_NAME)
@SideBarItem(sectionId = Sections.VIEWS, caption = "Select View")
@VaadinFontIcon(VaadinIcons.ARCHIVE)
public class SelectView extends CustomComponent implements View {

  public final static String VIEW_NAME = "SelectPersonView";

  @Autowired
  private SpringNavigator navigator;


  private MyBackend backend;

  @Autowired
  public SelectView(MyBackend backend) {
    this.backend = backend;

    //
    // Init call of the view (neutral or specified)
    //

    ActionResponse<SelectPerson> actionResponse = backend.initSelect();

    //
    // Declare UI components
    //

    DateField dfFrom = new DateField();
    DateField dfTill = new DateField();

    Grid<Person> personGrid = new Grid<>();

    personGrid.addColumn(Person::getFirstName).setCaption("First name");
    personGrid.addColumn(Person::getLastName).setCaption("Last name");

//    personGrid.getColumn(Person::getLastName).setCaption("Last name");

    Button btnLoad = new Button("Load");
    Button btnSelect = new Button("Select");

    //
    // Compose UI components
    //

    HorizontalLayout hlSelection = new HorizontalLayout();

    hlSelection.addComponent(new Label("From"));
    hlSelection.addComponent(dfFrom);
    hlSelection.addComponent(new Label("Till"));
    hlSelection.addComponent(dfTill);

    hlSelection.addComponents(dfFrom, dfTill, btnLoad);

    HorizontalLayout hlGrid = new HorizontalLayout();

    hlGrid.addComponents(personGrid, btnSelect);

    VerticalLayout vl = new VerticalLayout();

    vl.addComponent(hlSelection);
    vl.addComponent(hlGrid);

    setCompositionRoot(vl);

    //
    // Carrying of init call
    //

    List<SelectPerson> selectPersons = actionResponse.getData();
    SelectPerson selectPerson = selectPersons.get(0);

    dfFrom.setValue(selectPerson.getFrom());
    dfTill.setValue(selectPerson.getTill());

    //
    // Listener
    //

    btnLoad.addClickListener(ev -> {
      SelectPerson selectPersonToServer = new SelectPerson();

      selectPersonToServer.setFrom(dfFrom.getValue());
      selectPersonToServer.setTill(dfTill.getValue());

      ActionResponse<Person> actionResponseFromLoad = backend.loadSelection(selectPersonToServer);

      personGrid.setItems(actionResponseFromLoad.getData());
    });

    btnSelect.addClickListener(ev -> {
      Set<Person> selectedItems = personGrid.getSelectedItems();

      if (selectedItems.size() > 0) {
        Person person = selectedItems.iterator().next();

        VaadinSession.getCurrent().setAttribute(PersonView.VIEW_NAME + ".Id", person.getId());

        navigator.navigateTo(PersonView.VIEW_NAME);
      }
    });
  }

  @Override
  public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {
  }
}
